# Projeto-TCP
Repositório para o desenvolvimento do trabalho final de Técnicas de Construção de Programas

# Arquivo.bat
Para executar o programa, deve ser usado o arquivo .bat Projeto-TCP-Executavel.
