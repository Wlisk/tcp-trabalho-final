package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CombustionEngineTest {
    private CombustionEngine combustionEngine;

    @BeforeEach
    void setUp() {
        combustionEngine = new CombustionEngine();
    }

    @Test
    public void testSetAndGetCylinderCount() {
        combustionEngine.setCylinderCount(4);
        assertEquals(4, combustionEngine.getCylinderCount());

        combustionEngine.setCylinderCount(6);
        assertEquals(6, combustionEngine.getCylinderCount());
    }

    @Test
    public void testSetAndGetEngineSize() {
        combustionEngine.setSize(2.0);
        assertEquals(2.0, combustionEngine.getSize(), 0.001);
    }

    @Test
    public void testSetAndGetFuel() {
        combustionEngine.setFuel("Gasoline");
        assertEquals("Gasoline", combustionEngine.getFuel());

        combustionEngine.setFuel("Diesel");
        assertEquals("Diesel", combustionEngine.getFuel());
    }
}