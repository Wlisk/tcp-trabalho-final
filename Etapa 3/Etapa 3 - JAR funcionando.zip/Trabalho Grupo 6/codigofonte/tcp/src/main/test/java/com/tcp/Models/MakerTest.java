package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MakerTest {
    private Maker maker;

    @BeforeEach
    void setUp() {
        maker = new Maker();
    }

    @Test
    public void testSetAndGetName() {
        maker.setName("TestMaker");
        assertEquals("TestMaker", maker.getName());
    }

    @Test
    public void testSetAndGetNationality() {
        maker.setNationality("TestNationality");
        assertEquals("TestNationality", maker.getNationality());
    }

    @Test
    public void testSetAndGetFactoryInBrazil() {
        maker.setHasFactoryInCountry(true);
        assertTrue(maker.hasFactoryInCountry());
    }
}