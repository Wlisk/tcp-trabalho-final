package com.tcp.Utility;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UserInputParserTest {
	@Test
	public void stringToDoubleTest() {
		double delta = 0.001;
		
		assertEquals(1.5, UserInputParser.stringToDouble("1.5"), delta);
		assertEquals(1.0, UserInputParser.stringToDouble("1.0"), delta);
		assertEquals(10.5, UserInputParser.stringToDouble("10.5"), delta);
	}
}