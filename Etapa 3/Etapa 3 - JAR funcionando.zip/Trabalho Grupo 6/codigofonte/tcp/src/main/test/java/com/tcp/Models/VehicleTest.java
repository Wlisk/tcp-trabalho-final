package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class VehicleTest {
	private Vehicle vehicle;
	
	@BeforeEach
	void setUp() {
		// Assumindo 'Car' como implementação concreta de 'Vehicle'
    	// Observação: Somente os métodos da classe Vehicle serão testados aqui
		vehicle = new Car();
	}
	
	@Test
    public void testSetAndGetEngine() {
        CombustionEngine combustionEngine = new CombustionEngine();
        vehicle.setEngine(combustionEngine);
        assertEquals(combustionEngine, vehicle.getEngine());

        ElectricEngine electricEngine = new ElectricEngine();
        vehicle.setEngine(electricEngine);
        assertEquals(electricEngine, vehicle.getEngine());
    }

    @Test
    public void testSetAndGetMaker() {
        Maker maker = new Maker();
        vehicle.setMaker(maker);
        assertEquals(maker, vehicle.getMaker());
    }

    @Test
    public void testSetAndGetModel() {
        vehicle.setModel("ExampleModel");
        assertEquals("ExampleModel", vehicle.getModel());
    }

    @Test
    public void testSetAndGetColor() {
        vehicle.setColor("ExampleColor");
        assertEquals("ExampleColor", vehicle.getColor());
    }

    @Test
    public void testSetAndGetState() {
        vehicle.setState("ExampleState");
        assertEquals("ExampleState", vehicle.getState());
    }

    @Test
    public void testSetAndGetKm() {
        vehicle.setKm(10000);
        assertEquals(10000, vehicle.getKm());
    }

    @Test
    public void testSetAndGetModelYear() {
        vehicle.setModelYear(2022);
        assertEquals(2022, vehicle.getModelYear());
    }

    @Test
    public void testSetAndGetAutomatic() {
        vehicle.setAutomatic(true);
        assertTrue(vehicle.getGearBox().equals("Automático"));

        vehicle.setAutomatic(false);
        assertTrue(vehicle.getGearBox().equals("Manual"));
    }
}