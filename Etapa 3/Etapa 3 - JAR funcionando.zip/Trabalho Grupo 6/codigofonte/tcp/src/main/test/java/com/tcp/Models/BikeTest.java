package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BikeTest {
	private Bike bike;
	
	@BeforeEach
	void setUp() {
		bike = new Bike();
	}
	
	@Test
	public void testSetAndGetStyle() {
		bike.setStyle("Sportive");
		assertEquals("Sportive", bike.getStyle());
		
		bike.setStyle("Classic");
		assertEquals("Classic", bike.getStyle());
	}
}