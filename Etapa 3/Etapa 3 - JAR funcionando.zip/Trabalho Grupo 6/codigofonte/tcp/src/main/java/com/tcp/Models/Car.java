package com.tcp.Models;

public class Car extends Vehicle {

    private int doorCount, passengerCapacity;
    private String bodyStyle;
    private boolean airConditioning, powerSteering;

    public Car(){}
    
    public Car(int modelYear, String model, String trim, String color, int km, String state, int doorCount, int passengerCapacity, String bodyStyle, boolean airConditioning, boolean powerSteering) {
        this.setModelYear(modelYear);
        this.setModel(model);
        this.setTrim(trim);
        this.setColor(color);
        this.setKm(km);
        this.setState(state);
        this.setDoorCount(doorCount);
        this.setPassengerCapacity(passengerCapacity);
        this.setBodyStyle(bodyStyle);
        this.setAirConditioning(airConditioning);
        this.setPowerSteering(powerSteering);
    }

    public Car(Maker maker, Engine engine, int modelYear, String model, String trim, String color, int km, String state, int doorCount, int passengerCapacity, String bodyStyle, boolean airConditioning, boolean powerSteering, boolean automatic ) {
        this.setMaker(maker);
        this.setEngine(engine);
        this.setModelYear(modelYear);
        this.setModel(model);
        this.setTrim(trim);
        this.setColor(color);
        this.setKm(km);
        this.setState(state);
        this.setDoorCount(doorCount);
        this.setPassengerCapacity(passengerCapacity);
        this.setBodyStyle(bodyStyle);
        this.setAirConditioning(airConditioning);
        this.setPowerSteering(powerSteering);
        this.setAutomatic(automatic);
    }

    public int getDoorCount() {
        return this.doorCount;
    }
    
    public int getPassengerCapacity() {
        return this.passengerCapacity;
    }

    public String getBodyStyle() {
        return this.bodyStyle;
    }

    public boolean hasAirConditioning() {
        return this.airConditioning;
    }

    public boolean hasPowerSteering() {
        return this.powerSteering;
    }

    public void setDoorCount(int doorCount) {
        this.doorCount = doorCount;
    }

    public void setPassengerCapacity(int passengerCapacity) {
        this.passengerCapacity = passengerCapacity;
    }

    public void setBodyStyle(String bodyStyle) {
        this.bodyStyle = bodyStyle;
    }

    public void setAirConditioning(boolean airConditioning) {
        this.airConditioning = airConditioning;
    }

    public void setPowerSteering(boolean powerSteering){
        this.powerSteering = powerSteering;
    } 

}
