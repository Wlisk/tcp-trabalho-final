package com.tcp;

import com.tcp.Models.Bike;
import com.tcp.Models.Car;
import com.tcp.Models.CombustionEngine;
import com.tcp.Models.ElectricEngine;
import com.tcp.Models.Listing;
import com.tcp.Models.Maker;
import com.tcp.Models.User;

public class testData {

    public static void generateTestData() {

        generateAdminUser();

        App.addListing(
                        new Listing(
                            App.getCurrentUser(),new Car(new Maker("Volkswagen"), 
                            new CombustionEngine("AP20", "Diesel", 121, 17, 4, 2),
                            2001, "Gol", "COMFORTLINE 1.8", "Roxo",
                            160232, "Viamão, RS", 4, 5, "Hatch",
                            true, true, false), "Gol G3 super valorizado",
                            23900, "gol.jpg"
                        )
        );

        App.addListing(
                        new Listing(
                            App.getCurrentUser(),new Car(new Maker("Fiat"),
                            new CombustionEngine("Fire", "Gasolina",  75, 9, 4, 1),
                            2011, "Uno", "Economy", "Branco", 423012, "Paraná, RS",
                            2, 8, "Hatch", false, false, false),
                            "Uno de Firma", 17000, "uno.jpg"
                        )
                        
         );

        App.addListing(
                        new Listing(
                            App.getCurrentUser(),new Car(new Maker("Volkswagen"),
                            new CombustionEngine("TSI", "Gasolina", 130, 14, 4, 1),
                            2018, "Up", "TSI", "Preto", 83212, "Rio de Janeiro, RJ",
                            4, 4, "Hatch", true, true, true),
                            "Up Caixinha de Sorvete", 48990, "up.jpg"
                        )
        );

        App.addListing(
                        new Listing(
                            App.getCurrentUser(),new Bike(new Maker("Volt"),
                            new ElectricEngine("Motorzinho de Dentista", 32, 4, 100), 2020,
                            "Volt", "Start", "Vermelha", 4823, "Cajazeiras, PA", "Passeio", false),
                            "Motinho elétrica", 23990, "volt"
                        )
        );

        App.addListing(         
                        new Listing(
                            App.getCurrentUser(),new Bike(new Maker("Kawasaki"),
                            new CombustionEngine("H2R", "Gasolina", 242, 12, 2, 1), 2017,
                            "H2R", "R Turbo", "Preta", 24323, "São Paulo, SP", "Esportiva", true), 
                            "Moto mais rápida do mundo.", 244990, "h2r"
                        )
        );

        App.addListing(        
                        new Listing(
                            App.getCurrentUser(),new Car(new Maker("Chevrolet"),
                            new CombustionEngine("Familia1", "Etanol", 89, 13, 4, 2),
                            1994, "Monza", "SL/E", "Preto", 677998, "Chuí, RS", 2,
                            2, "Coupé", false, true, false),
                            "Usado apenas para viagens ao Paraguai.", 8990, "monza"
                        )
        );

        App.addListing(         
                        new Listing(
                            App.getCurrentUser(),new Car(new Maker("Tesla"),
                            new ElectricEngine("Tesla1", 772, 1002, 300),
                            2018, "Model S", "Plaid P100D", "Vermelho", 23912, "São Paulo, SP", 
                            4, 4, "Fastback", true, true, true),
                            "Tesla canhão", 749990, "models"
                        )
        );

        App.addListing(        
            new Listing(
                App.getCurrentUser(),new Car(new Maker("Fiat"),
                new CombustionEngine("Fire", "Etanol", 75, 9, 3, 1),
                2018, "Mobi", "like!", "Vermelho", 87232, "Florianópolis, SC",
                4, 4, "Hatch", true, true, true),
                "Ele tenta ser o uno.", 56900, "mobi"
            )
        );

    }

    public static void generateAdminUser(){
        App.addUser(new User("admin", "admin"));
    }
}
