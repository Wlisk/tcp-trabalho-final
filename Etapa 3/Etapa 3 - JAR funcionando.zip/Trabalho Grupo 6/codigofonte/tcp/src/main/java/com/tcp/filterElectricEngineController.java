package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class filterElectricEngineController {

    @FXML
    private TextField minElectricRangeField, maxElectricRangeField;

    public TextField getMaxElectricRangeField() {
        return this.minElectricRangeField;
    }

    public TextField getMinElectricRangeField() {
        return this.maxElectricRangeField;
    }

}
