package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class filterBikeController {
    @FXML
    private TextField styleField;

    public TextField getStyleField() {
        return this.styleField;
    }
}
