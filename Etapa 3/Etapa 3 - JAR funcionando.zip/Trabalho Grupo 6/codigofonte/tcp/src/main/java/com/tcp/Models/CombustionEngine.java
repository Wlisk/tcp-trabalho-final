package com.tcp.Models;

public class CombustionEngine extends Engine {
    
    private int cylinderCount;
    private double size;
    private String fuel;

    public CombustionEngine(){}

    public CombustionEngine(String name, String fuel, double power, double torque, int cylinderCount, double size) {
        this.setName(name);
        this.setFuel(fuel);
        this.setPower(power);
        this.setTorque(torque);
        this.setCylinderCount(cylinderCount);
        this.setSize(size);
    }
    
    public int getCylinderCount() {
        return this.cylinderCount;
    }

    public double getSize() {
        return this.size;
    }

    public String getFuel() {
        return this.fuel;
    }

    public void setCylinderCount(int cylinderCount) {
        this.cylinderCount = cylinderCount;
    }

    public void setSize(double size) {
        this.size = size;
    }
    
    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

}
