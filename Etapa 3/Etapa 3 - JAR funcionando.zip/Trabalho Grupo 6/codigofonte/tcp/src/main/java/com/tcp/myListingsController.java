package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public class myListingsController {

    @FXML
    private Button createListingBtn;

    @FXML
    private Hyperlink homeBtn, profileScreenBtn;

    @FXML
    private Label mainNameLabel;

    @FXML
    private VBox myListingsList;

    public void addSpacer() {
        Pane pane = new Pane();
        pane.setMinHeight(80);
        myListingsList.getChildren().add(pane);
    }

    public void initialize() {
        this.mainNameLabel.setText(App.getCurrentUser().getUsername());
        for (Listing listing : App.getUserListings()) {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("listingItem.fxml"));

            try {

                HBox listingItem = fxmlLoader.load();
                listingItemController listingItemController = fxmlLoader.getController();
                listingItemController.setData(listing);
                myListingsList.getChildren().add(listingItem);
                
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        addSpacer(); // Adiciona uma margem para os anúncios não ficarem atrás do botão flutuante.
    }
    
    @FXML
    void actionCreateListing(ActionEvent event) throws IOException {
        App.setRoot("createListing");
    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }

    @FXML
    void actionProfileScreen(ActionEvent event) {
        System.out.println("Você já está nessa tela seu animal.");
    }

    @FXML
    void actionFilterScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }


}
