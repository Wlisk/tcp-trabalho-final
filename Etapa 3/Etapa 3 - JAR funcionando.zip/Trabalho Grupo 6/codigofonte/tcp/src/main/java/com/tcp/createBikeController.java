package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class createBikeController {
    
    @FXML
    private TextField styleField;

    public String getStyleField() {
        return this.styleField.getText();
    }
}
