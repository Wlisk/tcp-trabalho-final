package com.tcp.Models;

public class Maker {

    private String name, nationality;
    private boolean hasFactoryInCountry;

    public Maker(){}

    public Maker(String makerName){
        this.setName(makerName);
    }

    public String getName() {
        return this.name;
    }

    public String getNationality() {
        return this.nationality;
    }

    public boolean hasFactoryInCountry() {
        return this.hasFactoryInCountry;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setHasFactoryInCountry(boolean hasFactoryInCountry) {
        this.hasFactoryInCountry = hasFactoryInCountry;
    }

}
