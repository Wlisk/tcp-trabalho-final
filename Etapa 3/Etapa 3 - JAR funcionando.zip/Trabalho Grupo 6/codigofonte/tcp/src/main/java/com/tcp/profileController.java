package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class profileController {

    @FXML
    private Label emailLabel, mainNameLabel, usernameLabel, nameLabel, phoneLabel;

    @FXML
    private Hyperlink homeBtn, profileScreenBtn;

     @FXML
    private VBox likedListingsView;

    public void initialize(){
        this.usernameLabel.setText(App.getCurrentUser().getUsername());
        this.mainNameLabel.setText(App.getCurrentUser().getUsername());
        this.nameLabel.setText(App.getCurrentUser().getName());
        this.emailLabel.setText(App.getCurrentUser().getEmail());
        this.phoneLabel.setText(App.getCurrentUser().getPhone());

        for(Listing likedListing : App.getLikedListings()) {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("listingItem.fxml"));

            try {

                HBox listingItem = fxmlLoader.load();
                listingItemController listingItemController = fxmlLoader.getController();
                listingItemController.setData(likedListing);
                likedListingsView.getChildren().add(listingItem);
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }

    @FXML
    void actionProfileScreen(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionFilterScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }

}
