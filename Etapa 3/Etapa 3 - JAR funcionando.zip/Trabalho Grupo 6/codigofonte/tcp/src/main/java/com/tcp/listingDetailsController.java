package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class listingDetailsController {

     @FXML
    private Hyperlink homeBtn, myListingsBtn;

    @FXML
    private Pane listingPane;

    @FXML
    private ImageView listingView;

    @FXML
    private Label locationLabel, modelLabel, modelYearLabel, sellerEmailLabel, sellerPhoneLabel, sellerUsernameLabel, trimLabel,
                    priceField, makerLabel, descriptionField, kmLabel;

    private Image listingImage;

    public void initialize() {

        Listing listing = App.findListingById(App.getListingId());

        this.modelYearLabel.setText(String.valueOf(listing.getVehicle().getModelYear()));
        this.makerLabel.setText(listing.getVehicle().getMaker().getName());
        this.modelLabel.setText(listing.getVehicle().getModel());
        this.descriptionField.setText(listing.getDescription());
        this.trimLabel.setText(listing.getVehicle().getTrim());
        this.kmLabel.setText(String.valueOf(listing.getVehicle().getKm()));
        this.locationLabel.setText(listing.getVehicle().getState());
        this.priceField.setText(String.valueOf(listing.getPrice()));
        this.sellerUsernameLabel.setText(listing.getOwner().getUsername());
        this.sellerPhoneLabel.setText(listing.getOwner().getPhone());
        this.sellerEmailLabel.setText(listing.getOwner().getEmail());
        this.listingImage = listing.getImage();

        if(this.listingImage != null) { //Seção usada para deixar a imagem responsiva
            double oldImageWidth = listingImage.getWidth(), oldImageHeight = listingImage.getHeight();            //Salvando o tamanho e o ratio da imagem original
            double imageRatio = oldImageWidth / oldImageHeight;

            listingView.setImage(listingImage);

            ChangeListener<Number> listener = (obs, ov, nv) -> {
                double paneWidth = listingPane.getWidth();
                double paneHeight = listingPane.getHeight();

                double paneRatio = paneWidth / paneHeight;                                          //Calculando o novo ratio do painel que contem a imagem
                                                                                                    //Depois que a largura ou altura mudar
                double newImageWidth = oldImageWidth, newImageHeight = oldImageHeight;
                
                if (paneRatio > imageRatio) {
                    newImageHeight = oldImageWidth / paneRatio;
                } else if (paneRatio < imageRatio) {
                    newImageWidth = oldImageHeight * paneRatio;
                }
                
                listingView.setViewport(new Rectangle2D(                                            // Retangulo usado como máscara para a iamgem
                        (oldImageWidth - newImageWidth) / 2, (oldImageHeight - newImageHeight) / 2, //Mudando a posição para cortar a imagem no centro
                        newImageWidth, newImageHeight)                                              //Nova largura e altura
                    );
                
                    listingView.setFitWidth(paneWidth);
            };

            listingPane.widthProperty().addListener(listener);
            listingPane.heightProperty().addListener(listener);
        }
    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }

    @FXML
    void actionMyListings(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionFilterScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }

}
