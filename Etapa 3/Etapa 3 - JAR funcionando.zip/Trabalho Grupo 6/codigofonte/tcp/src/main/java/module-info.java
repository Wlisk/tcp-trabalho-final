module com.tcp {
    requires transitive javafx.controls;
    requires javafx.fxml;

    opens com.tcp to javafx.fxml;
    exports com.tcp;
}
