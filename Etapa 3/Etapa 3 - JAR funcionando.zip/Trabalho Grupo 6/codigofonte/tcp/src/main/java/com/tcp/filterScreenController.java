package com.tcp;

import java.io.IOException;
import java.util.ArrayList;

import com.tcp.Models.Vehicle;
import com.tcp.Models.Bike;
import com.tcp.Models.Car;
import com.tcp.Models.Engine;
import com.tcp.Models.CombustionEngine;
import com.tcp.Models.ElectricEngine;
import com.tcp.Models.Listing;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class filterScreenController {

    @FXML
    private Hyperlink FiltersBtn, myListingBtn, homeBtn;

    @FXML
    private RadioButton bikeRadio, carRadio, combustionRadio, electricRadio;

    @FXML
    private Button filterBtn, filterResetBtn;

    @FXML
    private TextField makerField, minPriceField, maxPriceField, minYearField, maxYearField, modelField;

    /* Adições etapa 3 */
    @FXML
    private VBox engineFiltersSection, vehicleFiltersSection;

    @FXML
    private TextField trimField, colorField, ufField, minKmField, maxKmField, minPowerField, maxPowerField, minTorqueField, maxTorqueField;

    @FXML
    private RadioButton manualRadio, automaticRadio;

    @FXML
    private CheckBox airConditioningField, assistedSteeringField;

    private filterBikeController filterBikeController;
    private filterCarController filterCarController;
    private filterCombustionEngineController filterCombustionController;
    private filterElectricEngineController filterElectricController;

    public void initialize() {
        final ToggleGroup vehicleType = new ToggleGroup();
        this.carRadio.setToggleGroup(vehicleType);
        this.bikeRadio.setToggleGroup(vehicleType);
        final ToggleGroup engineType = new ToggleGroup();
        this.combustionRadio.setToggleGroup(engineType);
        this.electricRadio.setToggleGroup(engineType);
        final ToggleGroup gearboxRadioGroup = new ToggleGroup();
        this.automaticRadio.setToggleGroup(gearboxRadioGroup);
        this.manualRadio.setToggleGroup(gearboxRadioGroup);
    }

    @FXML
    void actionApplyFilters(ActionEvent event) throws IOException {
        ArrayList<Listing> allListings = new ArrayList<Listing>(resetFilters());
        ArrayList<Listing> filteredList = new ArrayList<Listing>();

        for (Listing listing : allListings) {
            if(isListingIncluded(listing))
                filteredList.add(listing); 
        }
        
        App.setRecommendedListings(filteredList);
        App.setRoot("home");
    }

    private boolean isListingIncluded(Listing listing){
        if (hasData(minPriceField) && listing.getPrice() < Double.parseDouble(minPriceField.getText())) return false;
        if (hasData(maxPriceField) && listing.getPrice() > Double.parseDouble(maxPriceField.getText())) return false;
    
        return isVehicleIncluded(listing.getVehicle());
    }

    private boolean isVehicleIncluded(Vehicle vehicle){
        if (carRadio.isSelected() && vehicle.getClass() != Car.class) return false;
        if (bikeRadio.isSelected() && vehicle.getClass() != Bike.class) return false;
        if (combustionRadio.isSelected() && vehicle.getEngine().getClass() != CombustionEngine.class) return false;
        if (electricRadio.isSelected() && vehicle.getEngine().getClass() != ElectricEngine.class) return false;
        if (manualRadio.isSelected() && vehicle.getAutomatic()) return false;
        if (automaticRadio.isSelected() && !vehicle.getAutomatic()) return false;
        if (hasData(makerField) && !vehicle.getMaker().getName().equals(makerField.getText())) return false;
        if (hasData(modelField) && !vehicle.getModel().equals(modelField.getText())) return false;
        if (hasData(trimField) && !vehicle.getTrim().equals(trimField.getText())) return false;
        if (hasData(colorField) && !vehicle.getColor().equals(colorField.getText())) return false;
        if (hasData(ufField) && !vehicle.getState().equals(ufField.getText())) return false;
        if (hasData(minYearField) && vehicle.getModelYear() < Integer.parseInt(minYearField.getText())) return false;
        if (hasData(maxYearField) && vehicle.getModelYear() > Integer.parseInt(maxYearField.getText())) return false;
        if (hasData(minKmField) && vehicle.getKm() < Integer.parseInt(minKmField.getText())) return false;
        if (hasData(maxKmField) && vehicle.getKm() > Integer.parseInt(maxKmField.getText())) return false;

        if (!isEngineIncluded(vehicle.getEngine())) return false;

        if (vehicle.getClass() == Car.class && carRadio.isSelected()){
            return isCarIncluded((Car) (vehicle));
        } else if (vehicle.getClass() == Bike.class && bikeRadio.isSelected()){
            return isBikeIncluded((Bike) (vehicle));
        }            

        return true;
    }

    private boolean isCarIncluded(Car car){
        if(hasData(filterCarController.getBodyStyleField()) && !car.getBodyStyle().equals(filterCarController.getBodyStyleField().getText())) return false;
        if(hasData(filterCarController.getMinDoorsField()) && car.getDoorCount() < Integer.parseInt(filterCarController.getMinDoorsField().getText())) return false;
        if(hasData(filterCarController.getMaxDoorsField()) && car.getDoorCount() > Integer.parseInt(filterCarController.getMaxDoorsField().getText())) return false;
        if(hasData(filterCarController.getMinPassengersField()) && car.getPassengerCapacity() < Integer.parseInt(filterCarController.getMinPassengersField().getText())) return false;
        if(hasData(filterCarController.getMaxPassengersField()) && car.getPassengerCapacity() > Integer.parseInt(filterCarController.getMaxPassengersField().getText())) return false;

        if (filterCarController.getAirConditioningField().isSelected() || filterCarController.getAssistedSteeringField().isSelected()) {
            if (filterCarController.getAirConditioningField().isSelected() && !car.hasAirConditioning()) return false;
            if (filterCarController.getAssistedSteeringField().isSelected() && !car.hasPowerSteering()) return false;
        }
        
        return true;
    }

    private boolean isBikeIncluded(Bike bike){
        if(hasData(filterBikeController.getStyleField()) && !bike.getStyle().equals(filterBikeController.getStyleField().getText())) return false;

        return true;
    }

    private boolean isEngineIncluded(Engine engine){
        if (hasData(minPowerField) && engine.getPower() < Integer.parseInt(minPowerField.getText())) return false;
        if (hasData(maxPowerField) && engine.getPower() > Integer.parseInt(maxPowerField.getText())) return false;
        if (hasData(minTorqueField) && engine.getTorque() < Integer.parseInt(minTorqueField.getText())) return false;
        if (hasData(maxTorqueField) && engine.getTorque() > Integer.parseInt(maxTorqueField.getText())) return false;

        if (engine.getClass() == CombustionEngine.class && combustionRadio.isSelected()){
            return isCombustionEngineIncluded((CombustionEngine) (engine));
        } else if (engine.getClass() == ElectricEngine.class && electricRadio.isSelected()) {
            return isElectricEngineIncluded((ElectricEngine) (engine));
        }            

        return true;
    }

    private boolean isCombustionEngineIncluded(CombustionEngine engine){
        if (hasData(filterCombustionController.getMinCylindersField()) 
            && engine.getCylinderCount() < Integer.parseInt(filterCombustionController.getMinCylindersField().getText())) return false;
        if (hasData(filterCombustionController.getMaxCylindersField()) 
            && engine.getCylinderCount() > Integer.parseInt(filterCombustionController.getMaxCylindersField().getText())) return false;
        if (hasData(filterCombustionController.getMinEngineSizeField()) 
            && engine.getTorque() < Integer.parseInt(filterCombustionController.getMinEngineSizeField().getText())) return false;
        if (hasData(filterCombustionController.getMaxEngineSizeField()) 
            && engine.getTorque() > Integer.parseInt(filterCombustionController.getMaxEngineSizeField().getText())) return false;

        if (filterCombustionController.getDieselRadio().isSelected() && engine.getFuel() != "Diesel") return false;
        if (filterCombustionController.getEthanolRadio().isSelected() && engine.getFuel() != "Etanol") return false;
        if (filterCombustionController.getGasRadio().isSelected() && engine.getFuel() != "Gasolina") return false;

        return true;
    }

    private boolean isElectricEngineIncluded(ElectricEngine engine){
        if (hasData(filterElectricController.getMinElectricRangeField()) 
            && engine.getRange() < Double.parseDouble(filterElectricController.getMinElectricRangeField().getText())) return false;
        if (hasData(filterElectricController.getMaxElectricRangeField()) 
            && engine.getRange() > Double.parseDouble(filterElectricController.getMaxElectricRangeField().getText())) return false;
        
        return true;
    }

    public void showBikeFiltersSection() {
        this.vehicleFiltersSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("filtersBikeScreen.fxml"));

        try {
            VBox bikeFiltersSection = fxmlLoader.load();
            filterBikeController = fxmlLoader.getController();
            this.vehicleFiltersSection.getChildren().add(bikeFiltersSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetBikeFiltersSection(ActionEvent event) {
        showBikeFiltersSection();
    }

    public void showCarFiltersSection() {
        this.vehicleFiltersSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("filtersCarScreen.fxml"));

        try {
            VBox carFiltersSection = fxmlLoader.load();
            filterCarController = fxmlLoader.getController();
            this.vehicleFiltersSection.getChildren().add(carFiltersSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCarFiltersSection(ActionEvent event) {
        showCarFiltersSection();
    }

    public void showCombustionFiltersSection() {
        this.engineFiltersSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("filtersCombustionEngineScreen.fxml"));

        try {
            VBox combustionEngineSection = fxmlLoader.load();
            filterCombustionController = fxmlLoader.getController();
            this.engineFiltersSection.getChildren().add(combustionEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCombustionEngineSection(ActionEvent event) {
        showCombustionFiltersSection();
    }

    public void showElectricEngineFiltersSection() {
        this.engineFiltersSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("filtersElectricEngineScreen.fxml"));

        try {
            VBox electricEngineSection = fxmlLoader.load();
            filterElectricController = fxmlLoader.getController();
            this.engineFiltersSection.getChildren().add(electricEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetElectricEngineSection(ActionEvent event) {
       showElectricEngineFiltersSection();
    }

    public boolean hasData(TextField textField) {
        return !textField.getText().isBlank();
    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }

    @FXML
    void actionMyListings(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionResetFilters(ActionEvent event) throws IOException {
        App.setRecommendedListings(resetFilters());
        App.setRoot("home");
    }

    public ArrayList<Listing> resetFilters() {
        ArrayList<Listing> listings = new ArrayList<Listing>(App.getListings());
        ArrayList<Listing> newRecommendedListings = new ArrayList<Listing>();

        for (Listing listing : listings) {
            if (!App.getLikedListings().contains(listing))
                newRecommendedListings.add(listing);
        }

        return newRecommendedListings;
    }

}
