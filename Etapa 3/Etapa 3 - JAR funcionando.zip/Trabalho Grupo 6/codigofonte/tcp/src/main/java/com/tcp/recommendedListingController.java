package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class recommendedListingController {

    @FXML
    private Label modelYearLabel, modelLabel, makerLabel, trimLabel, locationLabel, kmLabel, priceLabel;

    @FXML
    private Pane listingPane;

    @FXML
    private ImageView listingView;

    @FXML
    private AnchorPane recommendedListingItem;

    private Image listingImage;

    public void initialize() {
        
    }

    public void setData(Listing listing) {
        this.modelYearLabel.setText(String.valueOf(listing.getVehicle().getModelYear()));
        this.makerLabel.setText(listing.getVehicle().getMaker().getName());
        this.modelLabel.setText(listing.getVehicle().getModel());
        this.trimLabel.setText(listing.getVehicle().getTrim());
        this.priceLabel.setText(String.valueOf(listing.getPrice()));
        this.kmLabel.setText(String.valueOf(listing.getVehicle().getKm()));
        this.locationLabel.setText(listing.getVehicle().getState());
        this.listingView.setImage(listing.getImage());
        this.listingImage = listing.getImage();
        if(this.listingImage != null) {
            double oldImageWidth = listingImage.getWidth(), oldImageHeight = listingImage.getHeight();            //saving the original image size and ratio
            double imageRatio = oldImageWidth / oldImageHeight;

            listingView.setImage(listingImage);

            ChangeListener<Number> listener = (obs, ov, nv) -> {
                double paneWidth = listingPane.getWidth();
                double paneHeight = listingPane.getHeight();

                double paneRatio = paneWidth / paneHeight;                                          //calculating the new pane's ratio 
                                                                                                    //after width or height changed
                double newImageWidth = oldImageWidth, newImageHeight = oldImageHeight;
                
                if (paneRatio > imageRatio) {
                    newImageHeight = oldImageWidth / paneRatio;
                } else if (paneRatio < imageRatio) {
                    newImageWidth = oldImageHeight * paneRatio;
                }
                
                listingView.setViewport(new Rectangle2D(                                     // The rectangle used to crop
                        (oldImageWidth - newImageWidth) / 2, (oldImageHeight - newImageHeight) / 2, //MinX and MinY to crop from the center
                        newImageWidth, newImageHeight)                                              // new width and height
                    );
                
                    listingView.setFitWidth(paneWidth);
            };

            listingPane.widthProperty().addListener(listener);
            listingPane.heightProperty().addListener(listener);
        }
    }

    @FXML
    void actionListingDetails(MouseEvent event) throws IOException {
        App.setRoot("listingDetails");
    }

}
