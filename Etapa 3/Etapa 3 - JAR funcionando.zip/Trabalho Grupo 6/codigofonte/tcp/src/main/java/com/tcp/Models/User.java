package com.tcp.Models;

import java.util.ArrayList;

public class User {

    private static final int MIN_USERNAME_LENGTH = 4;
    private static final int MAX_USERNAME_LENGTH = 32;
    private static final int MIN_PASSWORD_LENGTH = 4;
    private static final int MAX_PASSWORD_LENGTH = 32;


    private String name, email, phone;
    private int salesNum, numRatings;
    private double rating;
    private String username, password;
    private ArrayList<String> likedListings = new ArrayList<String>();

    public User(){}

    public User(String username, String password) {
        this.setUsername(username);
        this.setPassword(password);
        this.salesNum = 0;
        this.rating = 0;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPhone() {
        return this.phone;
    }

    public int getSalesNum() {
        return this.salesNum;
    }

    public int getNumRatings() {
        return this.numRatings;
    }

    public double getRating() {
        return this.rating;
    }

    public String getUsername() {
        return this.username;
    }

    public ArrayList<String> getLikedListingsId() {
        return this.likedListings;
    }

    public boolean validName(String fullName) {
        return fullName.length() > MIN_USERNAME_LENGTH && fullName.length() <= MAX_USERNAME_LENGTH;
    }

    public boolean setName(String name) {
        if (!validName(name))
            return false;
        else 
            this.name = name;
            return true;
    }

    public boolean validEmail(String email) {
        return true; // Método não implementado ainda
    }

    public boolean setEmail(String email) {
        if(!validEmail(email))
            return false;
        else
            this.email = email;
            return true;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void rateUser(double rating) {
        double oldRating = this.rating * this.numRatings;
        numRatings++;
        this.rating = (oldRating + rating)/numRatings;
    }

    public boolean validUsername(String username) {
        return username.length() > 1 && username.length() <= 16;
    }

    public boolean setUsername (String username) {
        if (!validUsername(username))
            return false;
        else
            this.username = username;
            return true;
    }

    public boolean verifyPassword(String enteredPassword) {
        return this.password.equals(enteredPassword);
    }

    public boolean validPassword(String password) {
        return password.length() >= MIN_PASSWORD_LENGTH && password.length() <= MAX_PASSWORD_LENGTH;
    }

    public boolean setPassword(String password) {
        if (!validPassword(password)) 
            return false;
        else 
            this.password = password;
            return true;
    }

    public void likeListing(String id) {
        this.likedListings.add(id);
    }

}