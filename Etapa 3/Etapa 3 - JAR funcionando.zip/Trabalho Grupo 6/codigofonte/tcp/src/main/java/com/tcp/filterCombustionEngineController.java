package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class filterCombustionEngineController {

    @FXML
    private TextField minCylindersField, maxCylindersField, minEngineSizeField, maxEngineSizeField;

    @FXML
    private RadioButton dieselRadio, ethanolRadio, gasRadio;

    public void initialize() {
        final ToggleGroup fuelRadioGroup = new ToggleGroup();
        this.dieselRadio.setToggleGroup(fuelRadioGroup);
        this.ethanolRadio.setToggleGroup(fuelRadioGroup);
        this.gasRadio.setToggleGroup(fuelRadioGroup);
        this.gasRadio.setSelected(true);
    }

    public TextField getMinCylindersField() {
        return this.minCylindersField;
    }
    public TextField getMaxCylindersField() {
        return this.maxCylindersField;
    }
    public TextField getMinEngineSizeField() {
        return this.minEngineSizeField;
    }
    public TextField getMaxEngineSizeField() {
        return this.maxEngineSizeField;
    }

    public RadioButton getDieselRadio() {
        return this.dieselRadio;
    }
    public RadioButton getEthanolRadio() {
        return this.ethanolRadio;
    }
    public RadioButton getGasRadio() {
        return this.gasRadio;
    }


    public String getFuel() {
        if(dieselRadio.isSelected())
            return "Diesel";
        if(ethanolRadio.isSelected())
            return "Etanol";
        if(gasRadio.isSelected())
            return "Gasolina";
        else
            return "Não especificado";
    }
}
