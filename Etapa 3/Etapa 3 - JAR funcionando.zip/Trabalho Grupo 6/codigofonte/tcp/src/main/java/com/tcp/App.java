package com.tcp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

import com.tcp.Models.Listing;
import com.tcp.Models.User;

/**
 * JavaFX App
 */
public class App extends Application {

    private static final String APP_NAME = "Findar";
    private static Scene scene;
    private static User currentUser;
    private static String listingId;
    private static ArrayList<User> users = new ArrayList<User>();
    private static ArrayList<Listing> listings = new ArrayList<Listing>();
    private static ArrayList<Listing> recommendedListings = new ArrayList<Listing>();
    //private Image image = new Image(getClass().getResourceAsStream("mobi.jpg"));


    public static String getAppName() {
        return APP_NAME;
    }

    public static User findUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username))
            return user;
        } 

        return null;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void addUser(User user) {
        users.add(user);
    }

    public static void addListing(Listing listing) {
        listings.add(listing);
        recommendedListings.add(listing);
    }

    public static void setListingId(String id) {
        listingId = id;
    }
 
    public static String getListingId() {
        return listingId;
    }

    public static void addLikedListing(String id) {
        currentUser.likeListing(id);
    }

    public static Listing findListingById(String id) {
        for (Listing listing : listings) {
            if (listing.getId().equals(id))
            return listing;
        }
        return null;
    }

    public static ArrayList<Listing> getUserListings() {
        ArrayList<Listing> userListings = new ArrayList<Listing>();
        for (Listing listing : App.getListings()) {
            if(listing.getOwner().getUsername() == App.currentUser.getUsername())
                userListings.add(listing);
        }
        return userListings;
    }

    public static ArrayList<Listing>  getListings() {
        return listings;
    }

    public static ArrayList<Listing> getLikedListings() {
        ArrayList<Listing> likedListings = new ArrayList<Listing>();
        for(String id : currentUser.getLikedListingsId()) {
            likedListings.add(App.findListingById(id));
        }
        return likedListings;
    }

    public static void setRecommendedListings(ArrayList<Listing> listings) {
        recommendedListings = new ArrayList<Listing>(listings);
    }

    public static ArrayList<Listing> getRecommendedListings() {
        return recommendedListings;
    }

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("login"));
        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        testData.generateAdminUser();
        setCurrentUser(users.get(0));
        testData.generateTestData();
        setRecommendedListings(App.getListings());
        launch();
    }

}