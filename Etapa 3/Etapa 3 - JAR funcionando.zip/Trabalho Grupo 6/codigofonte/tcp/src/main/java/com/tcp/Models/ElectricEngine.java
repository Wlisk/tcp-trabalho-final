package com.tcp.Models;

public class ElectricEngine extends Engine {
    
    private double range;

    public ElectricEngine(){}
    
    public ElectricEngine(String name, double power, double torque, double range) {
        this.setName(name);
        this.setPower(power);
        this.setTorque(torque);
        this.setRange(range); 
    }

    public double getRange() {
        return this.range;
    }

    public void setRange(double range) {
        this.range = range;
    }

}
