package com.tcp;

import java.io.IOException;

import com.tcp.Models.Bike;
import com.tcp.Models.Car;
import com.tcp.Models.CombustionEngine;
import com.tcp.Models.ElectricEngine;
import com.tcp.Models.Listing;
import com.tcp.Models.Maker;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class createListingController {

    private static final String INVALID_DATA_ERROR = "Por favor, verifique os dados informados.";

    @FXML
    private Hyperlink filterScreenBtn, homeBtn, myListingBtn;

    @FXML
    private Button createListingBtn;

    @FXML
    private TextField   descriptionField, colorField, engineCodeField, enginePowerField,
                        engineTorqueField, kmField, makerField, modelField, modelYearField, 
                        ufField, listingPriceField, imageNameField, trimField;

    @FXML
    private VBox EngineDetailsSection, vehicleDetailsSection;

    @FXML
    private RadioButton automaticRadio, bikeRadio, carRadio, combustionRadio,   
                        electricRadio, manualRadio;

    @FXML
    private Label errorMessage;

    private createBikeController createBikeController;
    private createCarController createCarController;
    private createCombustionEngineController createCombustionEngineController;
    private createElectricEngineController createElectricEngineController;

    public void initialize() {
        setToggleGroups();
        showCarDetailsSection();
        showCombustionDetailsSection();
    }

    private void setToggleGroups() {
        final ToggleGroup vehicleRadioGroup = new ToggleGroup();
        this.bikeRadio.setToggleGroup(vehicleRadioGroup);
        this.carRadio.setToggleGroup(vehicleRadioGroup);
        this.carRadio.setSelected(true);
        final ToggleGroup gearboxRadioGroup = new ToggleGroup();
        this.automaticRadio.setToggleGroup(gearboxRadioGroup);
        this.manualRadio.setToggleGroup(gearboxRadioGroup);
        this.manualRadio.setSelected(true);
        final ToggleGroup engineRadioGroup = new ToggleGroup();
        electricRadio.setToggleGroup(engineRadioGroup);
        this.combustionRadio.setToggleGroup(engineRadioGroup);
        this.combustionRadio.setSelected(true);
    }

    // Pode parecer que daria para usar uma função genérica para isso aqui,
    // mas como o controlador é específico, e não existe um controlador genérico
    // o qual os controladores das telas de seção de carros e motos extendem, 
    // precisamos de objetos diferentes.

    public void showBikeDetailsSection() {
        this.vehicleDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createBike.fxml"));

        try {
            VBox bikeDetailsSection = fxmlLoader.load();
            createBikeController = fxmlLoader.getController();
            this.vehicleDetailsSection.getChildren().add(bikeDetailsSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetBikeDetailsSection(ActionEvent event) {
        showBikeDetailsSection();
    }

    public void showCarDetailsSection() {
        this.vehicleDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createCar.fxml"));

        try {
            VBox carDetailsSection = fxmlLoader.load();
            createCarController = fxmlLoader.getController();
            this.vehicleDetailsSection.getChildren().add(carDetailsSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCarDetailsSection(ActionEvent event) {
        showCarDetailsSection();
    }

    public void showCombustionDetailsSection() {
        this.EngineDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createCombustionEngine.fxml"));

        try {
            VBox combustionEngineSection = fxmlLoader.load();
            createCombustionEngineController = fxmlLoader.getController();
            this.EngineDetailsSection.getChildren().add(combustionEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCombustionEngineSection(ActionEvent event) {
        showCombustionDetailsSection();
    }

    public void showElectricEngineDetailsSection() {
        this.EngineDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createElectricEngine.fxml"));

        try {
            VBox electricEngineSection = fxmlLoader.load();
            createElectricEngineController = fxmlLoader.getController();
            this.EngineDetailsSection.getChildren().add(electricEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetElectricEngineSection(ActionEvent event) {
       showElectricEngineDetailsSection();
    }

    @FXML
    void actionCreateListing(ActionEvent event) throws IOException {
        try {
            Listing createdListing = new Listing(App.getCurrentUser());

            Maker maker = new Maker();
            maker.setName(makerField.getText());

            ElectricEngine electricEngine = new ElectricEngine();
            if(this.electricRadio.isSelected())
                electricEngine = new ElectricEngine(engineCodeField.getText(), Integer.parseInt(enginePowerField.getText()), Integer.parseInt(engineTorqueField.getText()), createElectricEngineController.getElectricRangeField());
                
            CombustionEngine combustionEngine = new CombustionEngine();
            if(this.combustionRadio.isSelected())
                combustionEngine = new CombustionEngine(engineCodeField.getText(), createCombustionEngineController.getFuel(), Integer.parseInt(enginePowerField.getText()), Integer.parseInt(engineTorqueField.getText()),createCombustionEngineController.getCylinderCountField(), createCombustionEngineController.getEncineSizeField());

            Car car = new Car(); 
            if(this.carRadio.isSelected()) {
                car = new Car(Integer.parseInt(modelYearField.getText()),modelField.getText(),trimField.getText(),colorField.getText(),Integer.parseInt(kmField.getText()),ufField.getText(),createCarController.getDoorCountField(),createCarController.getPassengerCapacityField(),createCarController.getBodyStyleField(),createCarController.getAirConditioningField(),createCarController.getAssistedSteeringField());
                if (this.electricRadio.isSelected())
                    car.setEngine(electricEngine);
                if(this.combustionRadio.isSelected())
                    car.setEngine(combustionEngine);
                car.setMaker(maker);
                createdListing.setVehicle(car);
            }

            Bike bike = new Bike();
            if(this.bikeRadio.isSelected()) {
                bike = new Bike(Integer.parseInt(modelYearField.getText()), modelField.getText(), trimField.getText(),colorField.getText(), Integer.parseInt(kmField.getText()), ufField.getText(), createBikeController.getStyleField());
                if (this.electricRadio.isSelected())
                    bike.setEngine(electricEngine);
                if(this.combustionRadio.isSelected())
                    bike.setEngine(combustionEngine);
                bike.setMaker(maker);
                createdListing.setVehicle(bike);
            }

            createdListing.setDescription(descriptionField.getText());
            createdListing.setPrice(Double.parseDouble(listingPriceField.getText()));
            createdListing.setImage(imageNameField.getText());

            App.addListing(createdListing);

            //System.out.println("Anuncio criado, pertence a: " + createdListing.getOwner().getUsername() + "\ndescriçâo: " + createdListing.getDescription());

            App.setRoot("myListings");
        } catch(Exception e) {
            this.errorMessage.setText(INVALID_DATA_ERROR);
        }
    }

    @FXML
    void actionMyListings(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionFilterScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }


}
