package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class filterCarController {

    @FXML
    private TextField bodyStyleField, minDoorsField, maxDoorsField, minPassengersField, maxPassengersField;

    @FXML
    private CheckBox airConditioningField, assistedSteeringField;

    public TextField getBodyStyleField() {
        return this.bodyStyleField;
    }
    public TextField getMinDoorsField() {
        return this.minDoorsField;
    }
    public TextField getMaxDoorsField() {
        return this.maxDoorsField;
    }
    public TextField getMinPassengersField() {
        return this.minPassengersField;
    }
    public TextField getMaxPassengersField() {
        return this.maxPassengersField;
    }
    public CheckBox getAirConditioningField() {
        return this.airConditioningField;
    }
    public CheckBox getAssistedSteeringField() {
        return this.assistedSteeringField;
    }   
}
