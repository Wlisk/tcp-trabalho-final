package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class homeController {

    @FXML
    private ImageView profilePicture, listingView;

    @FXML
    private Label appNameLabel, outOfRecommendedLabel;

    @FXML
    private Hyperlink homeBtn, myListingsBtn, filtersScreenBtn;

    @FXML
    private Button dislikeButton, likeButton;

     @FXML
    private Pane listingPane;

    @FXML
    private AnchorPane recommendedListing, recommendedListingContainer;

    public void initialize() {
        this.appNameLabel.setText(App.getAppName());
        loadNewListing();
    }

    public void loadNewListing() {
        if (!App.getRecommendedListings().isEmpty()) {
            Listing newListing = App.getRecommendedListings().get(0);
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("recommendedListing.fxml"));

            try {

                AnchorPane recommendedListing = fxmlLoader.load();
                AnchorPane.setTopAnchor(recommendedListing, 0.0);
                AnchorPane.setBottomAnchor(recommendedListing, 0.0);
                AnchorPane.setLeftAnchor(recommendedListing, 0.0);
                AnchorPane.setRightAnchor(recommendedListing, 0.0);
                recommendedListingController recommendedListingController = fxmlLoader.getController();
                recommendedListingController.setData(newListing);
                recommendedListingContainer.getChildren().clear();
                recommendedListingContainer.getChildren().add(recommendedListing);
                App.setListingId(newListing.getId());
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            recommendedListingContainer.getChildren().clear();
            outOfRecommendedLabel.setText("Não há mais anúncios.");
        }
    }

    @FXML
    void actionDislikeListing(ActionEvent event) {
        if (!App.getRecommendedListings().isEmpty()) {
            App.getRecommendedListings().remove(0);
            loadNewListing();
        }
    }

    @FXML
    void actionLikeListing(ActionEvent event) {
        if (!App.getRecommendedListings().isEmpty()) {
            App.addLikedListing(App.getListingId());
            App.getRecommendedListings().remove(0);
            loadNewListing();
        }
    }

    @FXML
    void actionListingDetails(MouseEvent event) throws IOException {
        App.setRoot("listingDetails");
    }

    @FXML
    void actionHome(ActionEvent event) {
        System.out.println("Voce ja está na homescreen seu animal");
    }

    @FXML
    void actionMyListings(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionProfileScreen(MouseEvent event) throws IOException {
        App.setRoot("profileScreen");
    }

    @FXML
    void actionFiltersScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }

}
