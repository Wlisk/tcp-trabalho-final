package com.tcp.Models;

public class Bike extends Vehicle {
    private String style;

    public Bike(){}

    public Bike(int modelYear, String model, String trim, String color,int km, String state, String style) {
        this.setModelYear(modelYear);
        this.setModel(model);
        this.setTrim(trim);
        this.setColor(color);
        this.setKm(km);
        this.setState(state);
        this.setStyle(style);
    }

    public Bike(Maker maker, Engine engine, int modelYear, String model, String trim, String color,
        int km, String state, String style, boolean automatic ) {
        this.setMaker(maker);
        this.setEngine(engine);
        this.setModelYear(modelYear);
        this.setModel(model);
        this.setTrim(trim);
        this.setColor(color);
        this.setKm(km);
        this.setState(state);
        this.setStyle(style);
        this.setAutomatic(automatic);
    }

    public String getStyle() {
        return this.style;
    }

    public void setStyle(String style) {
        this.style = style;
    }
    
}
