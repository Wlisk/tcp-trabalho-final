package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ElectricEngineTest {
    private ElectricEngine electricEngine;

    @BeforeEach
    void setUp() {
        electricEngine = new ElectricEngine();
    }
    
    @Test
    public void testSetAndGetRange() {
        electricEngine.setRange(20000.0);
        assertEquals(20000.0, electricEngine.getRange(), 0.001);
        
        electricEngine.setRange(10000.0);
        assertEquals(10000.0, electricEngine.getRange(), 0.001);
    }
}