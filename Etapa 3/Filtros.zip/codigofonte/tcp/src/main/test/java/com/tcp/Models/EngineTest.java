package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EngineTest {
    private Engine engine;

    @BeforeEach
    void setUp() {
    	// Assumindo 'CombustionEngine' como implementação concreta de 'Engine'
    	// Observação: Somente os métodos da classe Engine serão testados aqui
        engine = new CombustionEngine();
    }
    
    @Test
    public void testSetAndGetName() {
    	engine.setName("EngineTest");
    	assertEquals("EngineTest", engine.getName());
    }

    @Test
    public void testSetAndGetEnginePower() {
        engine.setPower(150.0);
        assertEquals(150.0, engine.getPower(), 0.001);
    }

    @Test
    public void testSetAndGetEngineTorque() {
        engine.setTorque(200.0);
        assertEquals(200.0, engine.getTorque(), 0.001);
    }
}