package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CarTest {
	private Car car;
	
	@BeforeEach
	void setUp() {
		car = new Car();
	}
	
	@Test
    public void testSetAndGetDoorCount() {
        car.setDoorCount(4);
        assertEquals(4, car.getDoorCount());
        
        car.setDoorCount(2);
        assertEquals(2, car.getDoorCount());
    }

    @Test
    public void testSetAndGetPassengerCapacity() {
        car.setPassengerCapacity(5);
        assertEquals(5, car.getPassengerCapacity());

        car.setPassengerCapacity(7);
        assertEquals(7, car.getPassengerCapacity());
    }

    @Test
    public void testSetAndGetBodyStyle() {
        car.setBodyStyle("Sedan");
        assertEquals("Sedan", car.getBodyStyle());

        car.setBodyStyle("Hatchback");
        assertEquals("Hatchback", car.getBodyStyle());
    }

    @Test
    public void testSetAndHasAirConditioning() {
        car.setAirConditioning(true);
        assertTrue(car.hasAirConditioning());

        car.setAirConditioning(false);
        assertFalse(car.hasAirConditioning());
    }

    @Test
    public void testSetAndHasPowerSteering() {
        car.setPowerSteering(true);
        assertTrue(car.hasPowerSteering());

        car.setPowerSteering(false);
        assertFalse(car.hasPowerSteering());
    }
    
    @Test
    public void testSetAndGetAirbag() {
        car.setAirbag(true);
        assertTrue(car.getAirBag());

        car.setAirbag(false);
        assertFalse(car.getAirBag());
    }
}