package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ListingTest {
    private Listing listing;
    private User testUser;
    private Vehicle testVehicle;

    @BeforeEach
    void setUp() {
        testUser = new User("testUser", "testPassword");
        listing = new Listing(testUser);
    }

    @Test
    public void testGetId() {
        assertNotNull(listing.getId());
    }

    @Test
    public void testSetAndGetOwner() {
        assertEquals(testUser, listing.getOwner());
    }

    @Test
    public void testSetAndGetVehicle() {
    	testVehicle = new Car();
    	listing.setVehicle(testVehicle);
    	assertEquals(testVehicle, listing.getVehicle());
    }

    @Test
    public void testSetAndGetDescription() {
        assertEquals("O criador do Anúncio não forneceu descrição.", listing.getDescription());
        listing.setDescription("Test Description");
        assertEquals("Test Description", listing.getDescription());
    }

    @Test
    public void testSetAndGetPrice() {
        assertEquals(0.0, listing.getPrice(), 0.001);
        listing.setPrice(10000.0);
        assertEquals(10000.0, listing.getPrice(), 0.001);
    }
}