package com.tcp.Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class UserTest {
    private User user;

    @BeforeEach
    void setUp() {
        user = new User("testUsername", "testPassword");
    }

    @Test
    public void testSetAndGetUsername() {
        assertTrue(user.setUsername("newUsername"));
        assertEquals("newUsername", user.getUsername());

        assertFalse(user.setUsername("a")); // Deve ser falso pois o número de caracteres é menor que o mínimo definido
        assertEquals("newUsername", user.getUsername()); // Username deve se manter inalterado
    }

    @Test
    public void testSetAndGetPassword() {
        assertTrue(user.setPassword("newPassword"));
        assertTrue(user.verifyPassword("newPassword"));

        assertFalse(user.setPassword("abc")); // Deve ser falso pois o número de caracteres é menor que o mínimo definido
        assertTrue(user.verifyPassword("newPassword")); // Senha deve se manter inalterada
    }

    @Test
    public void testSetName() {
        assertTrue(user.setName("Gabriel Carvalho"));
        assertEquals("Gabriel Carvalho", user.getName());

        assertFalse(user.setName("a")); // Deve ser falso pois o número de caracteres é menor que o mínimo definido
        assertEquals("Gabriel Carvalho", user.getName()); // Nome deve se manter inalterado
    }

    @Test
    public void testSetAndGetEmail() {
        assertTrue(user.setEmail("test@gmail.com"));
        assertEquals("test@gmail.com", user.getEmail());
        
        assertFalse(user.setEmail("@usertest.com"));
        assertEquals("test@gmail.com", user.getEmail());
    }

    @Test
    public void testRateUser() {
        user.rateUser(4.5);
        assertEquals(4.5, user.getRating(), 0.001);

        user.rateUser(3.0);
        assertEquals((4.5 + 3.0) / 2, user.getRating(), 0.001);
    }

    @Test
    public void testLikeListing() {
        assertTrue(user.getLikedListingsId().isEmpty());

        user.likeListing("listing1");
        assertEquals(1, user.getLikedListingsId().size());
        assertTrue(user.getLikedListingsId().contains("listing1"));
    }

    @Test
    public void testVerifyPassword() {
    	user.setPassword("testPassword");
        assertTrue(user.verifyPassword("testPassword"));
        assertFalse(user.verifyPassword("wrongPassword"));
    }
}