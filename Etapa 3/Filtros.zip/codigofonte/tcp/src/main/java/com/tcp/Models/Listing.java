package com.tcp.Models;

import java.io.InputStream;
import java.util.UUID;

import com.tcp.App;

import javafx.scene.image.Image;

public class Listing {

    private static final String NO_DESCRIPTION_TEXT = "O criador do Anúncio não forneceu descrição.";
    private static final String DEFAULT_LISTING_IMAGE = "ghost.png";

    private String id;
    private User owner;
    private Vehicle vehicle;
    private String description;
    private double price;

    private Image listingImage;

    public Listing(User creator) {
        this.owner = creator;
        this.description = NO_DESCRIPTION_TEXT;
        this.id = UUID.randomUUID().toString();
        this.setImage(DEFAULT_LISTING_IMAGE);
    }
    public String getId() {
        return this.id;
    }
    public User getOwner() {
        return this.owner;
    }
    public Vehicle getVehicle() {
        return vehicle;
    }
    public String getDescription() {
        return this.description;
    }
    public double getPrice() {
        return price;
    }
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public Image getImage() {
        return this.listingImage;
    }

    public Image formatImageName(String imageName) {

        boolean foundImage = App.class.getResourceAsStream(imageName) != null;
        boolean foundJpgImage = App.class.getResourceAsStream(imageName +  ".jpg") != null;
        boolean foundPngImage = App.class.getResourceAsStream(imageName + ".png") != null;
        boolean foundDefaultImage = App.class.getResourceAsStream(DEFAULT_LISTING_IMAGE) != null;
        if (foundImage)
            return new Image(App.class.getResourceAsStream(imageName));
        if (foundJpgImage)
            return new Image(App.class.getResourceAsStream(imageName + ".jpg"));
        if (foundPngImage)
            return new Image(App.class.getResourceAsStream(imageName + ".png"));
        if (foundDefaultImage)
            return new Image(App.class.getResourceAsStream(DEFAULT_LISTING_IMAGE));
        else 
            return null;
    }
    public void setImage(String imageName) {
        this.listingImage = formatImageName(imageName);
    }
 }
