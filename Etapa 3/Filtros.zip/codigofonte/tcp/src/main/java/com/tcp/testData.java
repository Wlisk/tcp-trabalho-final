package com.tcp;

import com.tcp.Models.Bike;
import com.tcp.Models.Car;
import com.tcp.Models.CombustionEngine;
import com.tcp.Models.ElectricEngine;
import com.tcp.Models.Engine;
import com.tcp.Models.Listing;
import com.tcp.Models.Maker;
import com.tcp.Models.User;
import com.tcp.Models.Vehicle;

public class testData {

    public static void generateTestData() {
        generateAdminUser();
        Listing listing = generateListing(
                                generateCar(generateMaker("Volkswagen"), 
                                generateCombustionEngine("AP20", "Diesel", 121, 17, 4, 2),
                                2001, "Gol", "COMFORTLINE 1.8", "Roxo",
                                160232, "Viamão, RS", 4, 5, "Hatch",
                                true, true, false), "Gol G3 super valorizado",
                                23900, "gol.jpg");
        App.addListing(listing);

        listing = generateListing(generateCar(generateMaker("Fiat"),
                                    generateCombustionEngine("Fire", "Gasolina",  75, 9, 4, 1),
                                    2011, "Uno", "Economy", "Branco", 423012, "Paraná, RS",
                                    2, 8, "Hatch", false, false, false),
                                    "Uno de Firma", 17000, "uno.jpg");
        App.addListing(listing);

        listing = generateListing(generateCar(generateMaker("Volkswagen"),
                                    generateCombustionEngine("TSI", "Gasolina", 130, 14, 4, 1),
                                    2018, "Up", "TSI", "Preto", 83212, "Rio de Janeiro, RJ",
                                    4, 4, "Hatch", true, true, true),
                                    "Up Caixinha de Sorvete", 48990, "up.jpg");
        App.addListing(listing);

        listing = generateListing(generateBike(generateMaker("Volt"),
                                    generateElectricEngine("Motorzinho de Dentista", 32, 4, 100), 2020,
                                    "Volt", "Start", "Vermelha", 4823, "Cajazeiras, PA", "Passeio", false),
                                     "Motinho elétrica", 23990, "volt");

        App.addListing(listing);

        listing = generateListing(generateBike(generateMaker("Kawasaki"),
                    generateCombustionEngine("H2R", "Gasolina", 242, 12, 2, 1), 2017,
                    "H2R", "R Turbo", "Preta", 24323, "São Paulo, SP", "Esportiva", true), 
                    "Moto mais rápida do mundo.", 244990, "h2r");

        App.addListing(listing);

        listing = generateListing(generateCar(generateMaker("Chevrolet"),
                    generateCombustionEngine("Familia1", "Etanol", 89, 13, 4, 2),
                    1994, "Monza", "SL/E", "Preto", 677998, "Chuí, RS", 2,
                    2, "Coupé", false, true, false),
                    "Usado apenas para viagens ao Paraguai.", 8990, "monza");

        App.addListing(listing);

        listing = generateListing(generateCar(generateMaker("Tesla"),
                    generateElectricEngine("Tesla1", 772, 1002, 300),
                    2018, "Model S", "Plaid P100D", "Vermelho", 23912, "São Paulo, SP", 
                    4, 4, "Fastback", true, true, true),
                    "Tesla canhão", 749990, "models");

        App.addListing(listing);

        listing = generateListing(generateCar(generateMaker("Fiat"),
        generateCombustionEngine("Fire", "Etanol", 75, 9, 3, 1),
        2018, "Mobi", "like!", "Vermelho", 87232, "Florianópolis, SC",
        4, 4, "Hatch", true, true, true),
        "Ele tenta ser o uno.", 56900, "mobi");

        App.addListing(listing);

    }
    
    public static void generateAdminUser() {
        App.addUser(new User("admin", "admin"));
    }

    public static Maker generateMaker(String makerName) {
        Maker maker = new Maker();
        maker.setName(makerName);
        return maker;
    }

    public static CombustionEngine generateCombustionEngine(String name, String fuel, int power, int torque, int cylinderCount, int size) {
        CombustionEngine engine = new CombustionEngine();
        engine.setName(name);
        engine.setFuel(fuel);
        engine.setPower(power);
        engine.setTorque(torque);
        engine.setCylinderCount(cylinderCount);
        engine.setSize(size);
        return engine;
    }

    public static ElectricEngine generateElectricEngine(String name, int power, int torque, int range) {
        ElectricEngine engine = new ElectricEngine();
        engine.setName(name);
        engine.setPower(power);
        engine.setTorque(torque);
        engine.setRange(range);
        return engine;
    }

    public static Car generateCar(Maker maker, Engine engine, int modelYear, String model, String trim, String color,
     int km, String state, int doorCount, int passengerCapacity, String bodyStyle,
     boolean airConditioning, boolean powerSteering, boolean automatic ) {
        Car vehicle = new Car();
        vehicle.setMaker(maker);
        vehicle.setEngine(engine);
        vehicle.setModelYear(modelYear);
        vehicle.setModel(model);
        vehicle.setTrim(trim);
        vehicle.setColor(color);
        vehicle.setKm(km);
        vehicle.setState(state);
        vehicle.setDoorCount(doorCount);
        vehicle.setPassengerCapacity(passengerCapacity);
        vehicle.setBodyStyle(bodyStyle);
        vehicle.setAirConditioning(airConditioning);
        vehicle.setPowerSteering(powerSteering);
        vehicle.setAutomatic(automatic);
        return vehicle;
    }

    public static Bike generateBike(Maker maker, Engine engine, int modelYear, String model, String trim, String color,
     int km, String state, String style, boolean automatic ) {
        Bike vehicle = new Bike();
        vehicle.setMaker(maker);
        vehicle.setEngine(engine);
        vehicle.setModelYear(modelYear);
        vehicle.setModel(model);
        vehicle.setTrim(trim);
        vehicle.setColor(color);
        vehicle.setKm(km);
        vehicle.setState(state);
        vehicle.setStyle(style);
        vehicle.setAutomatic(automatic);
        return vehicle;
    }

    public static Listing generateListing(Vehicle vehicle, String description, double price, String image) {
        Listing createdListing = new Listing(App.getCurrentUser());
        createdListing.setVehicle(vehicle);
        createdListing.setDescription(description);
        createdListing.setPrice(price);
        createdListing.setImage(image);
        return createdListing;
    }

}
