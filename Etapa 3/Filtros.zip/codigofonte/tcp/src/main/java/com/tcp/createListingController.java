package com.tcp;

import java.io.IOException;

import com.tcp.Models.Bike;
import com.tcp.Models.Car;
import com.tcp.Models.CombustionEngine;
import com.tcp.Models.ElectricEngine;
import com.tcp.Models.Listing;
import com.tcp.Models.Maker;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class createListingController {

    private static final String INVALID_DATA_ERROR = "Por favor, verifique os dados informados.";

    @FXML
    private Hyperlink filterScreenBtn, homeBtn, myListingBtn;

    @FXML
    private Button createListingBtn;

    @FXML
    private TextField   descriptionField, colorField, engineCodeField, enginePowerField,
                        engineTorqueField, kmField, makerField, modelField, modelYearField, 
                        ufField, listingPriceField, imageNameField, trimField;

    @FXML
    private VBox EngineDetailsSection, vehicleDetailsSection;

    @FXML
    private RadioButton automaticRadio, bikeRadio, carRadio, combustionRadio,   
                        electricRadio, manualRadio;

    @FXML
    private Label errorMessage;

    private createBikeController createBikeController;
    private createCarController createCarController;
    private createCombustionEngineController createCombustionEngineController;
    private createElectricEngineController createElectricEngineController;

    public void initialize() {
        setToggleGroups();
        showCarDetailsSection();
        showCombustionDetailsSection();
    }

    private void setToggleGroups() {
        final ToggleGroup vehicleRadioGroup = new ToggleGroup();
        this.bikeRadio.setToggleGroup(vehicleRadioGroup);
        this.carRadio.setToggleGroup(vehicleRadioGroup);
        this.carRadio.setSelected(true);
        final ToggleGroup gearboxRadioGroup = new ToggleGroup();
        this.automaticRadio.setToggleGroup(gearboxRadioGroup);
        this.manualRadio.setToggleGroup(gearboxRadioGroup);
        this.manualRadio.setSelected(true);
        final ToggleGroup engineRadioGroup = new ToggleGroup();
        electricRadio.setToggleGroup(engineRadioGroup);
        this.combustionRadio.setToggleGroup(engineRadioGroup);
        this.combustionRadio.setSelected(true);
    }

    // Pode parecer que daria para usar uma função genérica para isso aqui,
    // mas como o controlador é específico, e não existe um controlador genérico
    // o qual os controladores das telas de seção de carros e motos extendem, 
    // precisamos de objetos diferentes.

    public void showBikeDetailsSection() {
        this.vehicleDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createBike.fxml"));

        try {
            VBox bikeDetailsSection = fxmlLoader.load();
            createBikeController = fxmlLoader.getController();
            this.vehicleDetailsSection.getChildren().add(bikeDetailsSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetBikeDetailsSection(ActionEvent event) {
        showBikeDetailsSection();
    }

    public void showCarDetailsSection() {
        this.vehicleDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createCar.fxml"));

        try {
            VBox carDetailsSection = fxmlLoader.load();
            createCarController = fxmlLoader.getController();
            this.vehicleDetailsSection.getChildren().add(carDetailsSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCarDetailsSection(ActionEvent event) {
        showCarDetailsSection();
    }

    public void showCombustionDetailsSection() {
        this.EngineDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createCombustionEngine.fxml"));

        try {
            VBox combustionEngineSection = fxmlLoader.load();
            createCombustionEngineController = fxmlLoader.getController();
            this.EngineDetailsSection.getChildren().add(combustionEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetCombustionEngineSection(ActionEvent event) {
        showCombustionDetailsSection();
    }

    public void showElectricEngineDetailsSection() {
        this.EngineDetailsSection.getChildren().clear();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("createElectricEngine.fxml"));

        try {
            VBox electricEngineSection = fxmlLoader.load();
            createElectricEngineController = fxmlLoader.getController();
            this.EngineDetailsSection.getChildren().add(electricEngineSection);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void actionSetElectricEngineSection(ActionEvent event) {
       showElectricEngineDetailsSection();
    }

    public ElectricEngine createElectricEngine() {
        ElectricEngine engine = new ElectricEngine();
        engine.setName(engineCodeField.getText());
        engine.setPower(Integer.parseInt(enginePowerField.getText()));
        engine.setTorque(Integer.parseInt(engineTorqueField.getText()));
        engine.setRange(createElectricEngineController.getElectricRangeField());
        return engine;
    }

    public CombustionEngine createCombustionEngine() {
        CombustionEngine engine = new CombustionEngine();
        engine.setName(engineCodeField.getText());
        engine.setPower(Integer.parseInt(enginePowerField.getText()));
        engine.setTorque(Integer.parseInt(engineTorqueField.getText()));
        engine.setCylinderCount(createCombustionEngineController.getCylinderCountField());
        engine.setSize(createCombustionEngineController.getEncineSizeField());
        engine.setFuel(createCombustionEngineController.getFuel());
        return engine;
    }

    public Car createCar() {
        Car vehicle = new Car();
        vehicle.setModelYear(Integer.parseInt(modelYearField.getText()));
        vehicle.setModel(modelField.getText());
        vehicle.setTrim(trimField.getText());
        vehicle.setColor(colorField.getText());
        vehicle.setKm(Integer.parseInt(kmField.getText()));
        vehicle.setState(ufField.getText());
        vehicle.setDoorCount(createCarController.getDoorCountField());
        vehicle.setPassengerCapacity(createCarController.getPassengerCapacityField());
        vehicle.setBodyStyle(createCarController.getBodyStyleField());
        vehicle.setAirConditioning(createCarController.getAirConditioningField());
        vehicle.setPowerSteering(createCarController.getAssistedSteeringField());
        return vehicle;
    }

    public Bike createBike() {
        Bike vehicle = new Bike();
        vehicle.setModelYear(Integer.parseInt(modelYearField.getText()));
        vehicle.setModel(modelField.getText());
        vehicle.setTrim(trimField.getText());
        vehicle.setColor(colorField.getText());
        vehicle.setKm(Integer.parseInt(kmField.getText()));
        vehicle.setState(ufField.getText());
        vehicle.setStyle(createBikeController.getStyleField());
        return vehicle;
    }

    @FXML
    void actionCreateListing(ActionEvent event) throws IOException {
        try {
            Listing createdListing = new Listing(App.getCurrentUser());

            Maker maker = new Maker();
            maker.setName(makerField.getText());

            ElectricEngine electricEngine = new ElectricEngine();
            if(this.electricRadio.isSelected())
                electricEngine = createElectricEngine();
                
            CombustionEngine combustionEngine = new CombustionEngine();
            if(this.combustionRadio.isSelected())
                combustionEngine = createCombustionEngine();

            Car car = new Car(); 
            if(this.carRadio.isSelected()) {
                car = createCar();
                if (this.electricRadio.isSelected())
                    car.setEngine(electricEngine);
                if(this.combustionRadio.isSelected())
                    car.setEngine(combustionEngine);
                car.setMaker(maker);
                createdListing.setVehicle(car);
            }

            Bike bike = new Bike();
            if(this.bikeRadio.isSelected()) {
                bike = createBike();
                if (this.electricRadio.isSelected())
                    bike.setEngine(electricEngine);
                if(this.combustionRadio.isSelected())
                    bike.setEngine(combustionEngine);
                bike.setMaker(maker);
                createdListing.setVehicle(bike);
            }

            createdListing.setDescription(descriptionField.getText());
            createdListing.setPrice(Double.parseDouble(listingPriceField.getText()));
            createdListing.setImage(imageNameField.getText());

            App.addListing(createdListing);

            //System.out.println("Anuncio criado, pertence a: " + createdListing.getOwner().getUsername() + "\ndescriçâo: " + createdListing.getDescription());

            App.setRoot("myListings");
        } catch(Exception e) {
            this.errorMessage.setText(INVALID_DATA_ERROR);
        }
    }

    @FXML
    void actionMyListings(ActionEvent event) throws IOException {
        App.setRoot("myListings");
    }

    @FXML
    void actionFilterScreen(ActionEvent event) throws IOException {
        App.setRoot("filtersScreen");
    }

    @FXML
    void actionHome(ActionEvent event) throws IOException {
        App.setRoot("home");
    }


}
