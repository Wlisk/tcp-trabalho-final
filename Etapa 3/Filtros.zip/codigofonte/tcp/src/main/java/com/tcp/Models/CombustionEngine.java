package com.tcp.Models;

public class CombustionEngine extends Engine {
    
    private int cylinderCount;
    private double size;
    private String fuel;
    
    public int getCylinderCount() {
        return this.cylinderCount;
    }
    public double getSize() {
        return this.size;
    }
    public String getFuel() {
        return this.fuel;
    }
    public void setCylinderCount(int cylinderCount) {
        this.cylinderCount = cylinderCount;
    }
    public void setSize(double size) {
        this.size = size;
    }
    public void setFuel(String fuel) {
        this.fuel = fuel;
    }
}
