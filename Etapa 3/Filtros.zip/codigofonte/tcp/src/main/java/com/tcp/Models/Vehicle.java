package com.tcp.Models;

public abstract class Vehicle {
    
    private Maker maker;
    private Engine engine;
    private String model, trim, color, state;
    private int km, modelYear;
    private boolean airbag, automatic;

    public Maker getMaker() {
        return this.maker;
    }
    public Engine getEngine() {
        return this.engine;
    }
    public String getModel() {
        return this.model;
    }
    public String getTrim() {
        return this.trim;
    }
    public String getColor() {
        return this.color;
    }
    public String getState() {
        return this.state;
    }
    public int getKm() {
        return this.km;
    }
    public int getModelYear() {
        return this.modelYear;
    }
    public String getGearBox() {
        if(automatic)
            return "Automático";
        else
            return "Manual";
    }
    public boolean getAirBag() {
        return this.airbag;
    }
    public boolean getAutomatic() {
        return this.automatic;
    }
    public void setMaker(Maker maker) {
        this.maker = maker;
    }
    public void setEngine(Engine engine) {
        this.engine = engine;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public void setTrim(String trim) {
        this.trim = trim;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public void setState(String state) {
        this.state = state;
    }
    public void setKm(int km) {
        this.km = km;
    }
    public void setModelYear(int year) {
        this.modelYear = year;
    }
    public void setAirbag(boolean airbag) {
        this.airbag = airbag;
    }
    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }
}