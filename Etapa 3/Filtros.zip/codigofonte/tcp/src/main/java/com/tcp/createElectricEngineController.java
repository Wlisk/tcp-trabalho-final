package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class createElectricEngineController {

    @FXML
    private TextField electricRangeField;

    public double getElectricRangeField() {
        return Double.parseDouble(this.electricRangeField.getText());
    }
}
