package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class createCombustionEngineController {

    @FXML
    private TextField cylinderCountField, engineSizeField;

    @FXML
    private RadioButton dieselRadio, ethanolRadio, gasRadio;

    public void initialize() {
        final ToggleGroup fuelRadioGroup = new ToggleGroup();
        this.dieselRadio.setToggleGroup(fuelRadioGroup);
        this.ethanolRadio.setToggleGroup(fuelRadioGroup);
        this.gasRadio.setToggleGroup(fuelRadioGroup);
        this.gasRadio.setSelected(true);
    }
    public int getCylinderCountField() {
        return Integer.parseInt(this.cylinderCountField.getText());
    }
    public int getEncineSizeField() {
        return Integer.parseInt(this.engineSizeField.getText());
    }
    public String getFuel() {
        if(dieselRadio.isSelected())
            return "Diesel";
        if(ethanolRadio.isSelected())
            return "Etanol";
        if(gasRadio.isSelected())
            return "Gasolina";
        else
            return "Não especificado";
    }
}
