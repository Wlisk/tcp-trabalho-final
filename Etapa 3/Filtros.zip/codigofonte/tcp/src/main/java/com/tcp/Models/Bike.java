package com.tcp.Models;

public class Bike extends Vehicle {
    private String style;

    public String getStyle() {
        return this.style;
    }

    public void setStyle(String style) {
        this.style = style;
    }
}
