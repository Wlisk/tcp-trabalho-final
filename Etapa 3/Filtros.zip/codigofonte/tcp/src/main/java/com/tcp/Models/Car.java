package com.tcp.Models;

public class Car extends Vehicle {

    private int doorCount, passengerCapacity;
    private String bodyStyle;
    private boolean airConditioning, powerSteering;

    public int getDoorCount() {
        return this.doorCount;
    }
    public int getPassengerCapacity() {
        return this.passengerCapacity;
    }
    public String getBodyStyle() {
        return this.bodyStyle;
    }
    public boolean hasAirConditioning() {
        return this.airConditioning;
    }
    public boolean hasPowerSteering() {
        return this.powerSteering;
    }
    public void setDoorCount(int doorCount) {
        this.doorCount = doorCount;
    }
    public void setPassengerCapacity(int passengerCapacity) {
        this.passengerCapacity = passengerCapacity;
    }
    public void setBodyStyle(String bodyStyle) {
        this.bodyStyle = bodyStyle;
    }
    public void setAirConditioning(boolean airConditioning) {
        this.airConditioning = airConditioning;
    }
    public void setPowerSteering(boolean powerSteering){
        this.powerSteering = powerSteering;
    } 
}
