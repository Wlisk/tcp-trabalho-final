package com.tcp.Models;

public abstract class Engine {
    
    private String name;
    private double power, torque;

    public String getName() {
        return this.name;
    }
    public double getPower() {
        return this.power;
    }
    public double getTorque() {
        return this.torque;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPower(double power) {
        this.power = power;
    }
    public void setTorque(double torque) {
        this.torque = torque;
    }
}
