package com.tcp;

import java.io.IOException;

import com.tcp.Models.Listing;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;

public class listingItemController {

    @FXML
    private ImageView listingImg;

    @FXML
    private Label listingName;

    @FXML
    private HBox listingItem;

    private String listingId;

    public void setData(Listing listing) {
        listingId = listing.getId();
        listingName.setText(listing.getDescription());
        listingImg.setImage(listing.getImage());
    }

    public String getListingId() {
        return this.listingId;
    }

    @FXML
    void actionListingDetails(MouseEvent event) throws IOException {
        App.setListingId(listingId);
        App.setRoot("listingDetails");
    }

}
