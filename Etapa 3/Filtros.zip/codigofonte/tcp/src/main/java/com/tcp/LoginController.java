package com.tcp;

import java.io.IOException;

import com.tcp.Models.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    public static final String  NON_EXISTING_USER_MSG = "Nome de usuário não cadastrado no sistema.",
                                WRONG_PASSWORD_MSG = "Senha incorreta.";

    @FXML
    private Button createAcountBtn;

    @FXML
    private Button loginBtn;

    @FXML
    private TextField loginField;

    @FXML
    private PasswordField passwordField;

     @FXML
    private Label loginMessage;

    @FXML
    void actionCreateAccount(ActionEvent event) throws IOException {
        App.setRoot("createAccount");
    }

    @FXML
    void actionLogin(ActionEvent event) throws IOException {

        User loginAttempt = App.findUserByUsername(loginField.getText());
        if (loginAttempt == null)
            loginMessage.setText(NON_EXISTING_USER_MSG);
        else {
            if(loginAttempt.verifyPassword(passwordField.getText())) {
                App.setRoot("home");
                App.setCurrentUser(loginAttempt);
            }
            else  
                loginMessage.setText(WRONG_PASSWORD_MSG);
        }

    }
}
