package com.tcp;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class createCarController {

    @FXML
    private TextField bodyStyleField, doorCountField, passengerCapacityField;

    @FXML
    private CheckBox airConditioningField, assistedSteeringField;

    public String getBodyStyleField() {
        return this.bodyStyleField.getText();
    }
    public int getDoorCountField() {
        return Integer.parseInt(this.doorCountField.getText());
    }
    public int getPassengerCapacityField() {
        return Integer.parseInt(this.passengerCapacityField.getText());
    }
    public boolean getAirConditioningField() {
        return this.airConditioningField.isSelected();
    }
    public boolean getAssistedSteeringField() {
        return this.assistedSteeringField.isSelected();
    }
}
