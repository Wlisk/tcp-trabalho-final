package com.tcp;

import java.io.IOException;

import com.tcp.Models.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class createAccountController {

    private static final String INVALID_DATA_ERROR = "Por favor, verifique os dados informados.";
    private static final String EXISTING_USER_ERROR = "Nome de usuário indisponível.";

    private static int MIN_USERNAME_LENGTH = 4;
    private static int MAX_USERNAME_LENGTH = 32;
    private static int MIN_PASSWORD_LENGTH = 4;
    private static int MAX_PASSWORD_LENGTH = 32;

    @FXML
    private Button createAccountBtn, loginScreenBtn;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField, emailField, nameField, phoneField;

    @FXML
    private Label errorMessage;


    @FXML
    void actionCreateAccount(ActionEvent event) throws IOException {
        if (verifyUsername(usernameField.getText())){
            boolean validUsername = usernameField.getText().length() >= MIN_USERNAME_LENGTH && usernameField.getText().length() <= MAX_USERNAME_LENGTH;
            boolean validPassword = passwordField.getText().length() >= MIN_PASSWORD_LENGTH && passwordField.getText().length() <= MAX_PASSWORD_LENGTH ;
            if (validUsername && validPassword) {
                User createdUser = new User(usernameField.getText(), passwordField.getText());
                createdUser.setEmail(emailField.getText());
                createdUser.setName(nameField.getText());
                createdUser.setPhone(phoneField.getText());
                App.addUser(createdUser);
                App.setRoot("login");
            } else this.errorMessage.setText(INVALID_DATA_ERROR);
        } else this.errorMessage.setText(EXISTING_USER_ERROR);
    }
    @FXML
    void actionLoginScreen(ActionEvent event) throws IOException {
        App.setRoot("login");
    }
    private boolean verifyUsername(String username) {
        return App.findUserByUsername(username) == null;
    }
}
